<!DOCTYPE html>
<html lang="en-US" class="no-js">

 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>RBCL || Term and condition</title>

    <link rel='stylesheet' href='plugins/goodlayers-core/plugins/fontawesome/font-awesome.css' type='text/css' media='all'>
    <link rel='stylesheet' href='plugins/goodlayers-core/plugins/elegant/elegant-font.css' type='text/css' media='all'>
    <link rel='stylesheet' href='plugins/goodlayers-core/plugins/style.css' type='text/css' media='all'>
    <link rel='stylesheet' href='plugins/goodlayers-core/include/css/page-builder.css' type='text/css' media='all'>
    <link rel='stylesheet' href='plugins/revslider/public/assets/css/rs6.css' type='text/css' media='all'>
    <link rel='stylesheet' href='plugins/sportspress/assets/css/sportspress.css' type='text/css' media='all'>
    <link rel='stylesheet' href='plugins/sportspress/assets/css/icons.css' type='text/css' media='all'>
    <link rel='stylesheet' href='css/style-core.css' type='text/css' media='all'>
    <link rel='stylesheet' href='css/bigslam-style-custom.css' type='text/css' media='all'>
    <link rel='stylesheet' href='plugins/google-map-plugin/assets/css/frontend.css' type='text/css' media='all'>

    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto+Condensed%3A300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%7CRoboto%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C700%2C700italic%2C900%2C900italic%7CMerriweather%3A300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic%7CLora%3Aregular%2Citalic%2C700%2C700italic&amp;subset=cyrillic-ext%2Cvietnamese%2Clatin%2Ccyrillic%2Cgreek-ext%2Clatin-ext%2Cgreek&amp;ver=5.3' type='text/css' media='all'>



</head>

<body class="home page-template-default page page-id-5136 theme-bigslam gdlr-core-body woocommerce-no-js bigslam-body bigslam-body-front bigslam-full gdlr-core-link-to-lightbox">
    <div class="bigslam-mobile-header-wrap">
        <div class="bigslam-mobile-header bigslam-header-background bigslam-style-slide" id="bigslam-mobile-header">
            <div class="bigslam-mobile-header-container bigslam-container">
                <div class="bigslam-logo  bigslam-item-pdlr">
                    <div class="bigslam-logo-inner">
                        <a href="index.php"><img src="upload/RBCL-Logo1.png" alt="" width="200" height="191" title="logo"></a>
                    </div>
                </div>
                 
                <div class="bigslam-mobile-menu-right">
                    <div class="bigslam-main-menu-search" id="bigslam-mobile-top-search">
                      <div id="google_translate_element" class="form-currency top-select">
                           <script type="text/javascript">
                              function googleTranslateElementInit() {

                                 new google.translate.TranslateElement({ pageLanguage: 'select language', includedLanguages: 'hi,en,pa,gu,mr,ml,te,ta,kn,bn,ur,or', },

                                    'google_translate_element');

                              }
                           </script>
                           <script type="text/javascript"
                              src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                        </div>
                    </div>
                    <!--<div class="bigslam-top-search-wrap">-->
                    <!--    <div class="bigslam-top-search-close"></div>-->

                    <!--    <div class="bigslam-top-search-row">-->
                    <!--        <div class="bigslam-top-search-cell">-->
                    <!--            <form role="search" method="get" class="search-form" action="">-->
                    <!--                <input type="text" class="search-field bigslam-title-font" placeholder="Search..." value="" name="s">-->
                    <!--                <div class="bigslam-top-search-submit"><i class="fa fa-search"></i></div>-->
                    <!--                <input type="submit" class="search-submit" value="Search">-->
                    <!--                <div class="bigslam-top-search-close"><i class="icon_close"></i></div>-->
                    <!--            </form>-->
                    <!--        </div>-->
                    <!--    </div>-->

                    <!--</div>-->
                    <div class="bigslam-mobile-menu"><a class="bigslam-mm-menu-button bigslam-mobile-menu-button bigslam-mobile-button-hamburger-with-border" href="#bigslam-mobile-menu"><i class="fa fa-bars"></i></a>
                        <div class="bigslam-mm-menu-wrap bigslam-navigation-font" id="bigslam-mobile-menu" data-slide="right">
                            <ul id="menu-main-navigation" class="m-menu">
                                <li class="menu-item menu-item-home current-menu-item"><a href="index.php" aria-current="page">Home</a></li>
                                <li class="menu-item menu-item-has-children"><a href=" ">ABOUT US</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item"><a href="what-is-rbcl.php">WHAT IS RBCL</a></li>
                                        <li class="menu-item"><a href="rbcl-gallery.php">RBCL GALLERY</a></li>
                                        <li class="menu-item"><a href="rbcl-organisers.php">RBCL ORGANISERS</a></li>
                                        <!--<li class="menu-item"><a href="">RBCL ADVISORY BOARD</a></li>-->
                                        <!--<li class="menu-item"><a href="">RBCL POLICIES</a></li>-->
                                    </ul>
                                </li>
                                <li class="menu-item menu-item-has-children"><a href="">SELECTION</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item"><a href="rbcl-team.php">RBCL TEAM</a></li>
                                        <li class="menu-item"><a href="process.php">RBCL SELECTION PROCESS</a></li>
                                        <li class="menu-item"><a href="rbcl-documents.php">RBCL DOCUMENTS</a></li>
                                        <!--<li class="menu-item"><a href=" ">RBCL POLICIES</a></li>-->
                                    </ul>
                                </li>

<!--                                <li class="menu-item menu-item-has-children"><a href=" ">COMMITTEES</a>-->
<!--                                    <ul class="sub-menu">-->
<!--                                        <li class="menu-item"><a href="">ANTI-CORRUPTION COMMITTEE-->
<!--</a></li>-->
<!--                                        <li class="menu-item"><a href=" ">DISCIPLINARY COMMITTEE-->
<!--</a></li>-->
                                         
<!--                                    </ul>-->
<!--                                </li>-->

                                <li class="menu-item "><a href="rbcl-management.php">MANAGEMENT</a></li>

                                 <li class="menu-item "><a href="">TOUR MATCHES</a></li>
                                  <li class="menu-item "><a href="contact.php">CONTACT US</a></li>

                                  <li class="menu-item "><a href="pay-fees.php">PAY FEE</a></li>

                                   <li class="menu-item "><a href="registration.php">REGISTRATION</a></li>
                                 
                            
                                
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bigslam-body-outer-wrapper ">
        <div class="bigslam-body-wrapper clearfix  bigslam-with-transparent-header bigslam-with-frame">
            <div class="bigslam-header-background-transparent">
                <div class="bigslam-top-bar">
                    <div class="bigslam-top-bar-background"></div>
                    <div class="bigslam-top-bar-container clearfix bigslam-container ">
                        <div class="bigslam-top-bar-left bigslam-item-pdlr">
                             
                    
                        <div id="google_translate_element" class="form-currency top-select">
                           <script type="text/javascript">
                              function googleTranslateElementInit() {

                                 new google.translate.TranslateElement({ pageLanguage: 'select language', includedLanguages: 'hi,en,pa,gu,mr,ml,te,ta,kn,bn,ur,or', },

                                    'google_translate_element');

                              }
                           </script>
                           <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                        <div class="skiptranslate goog-te-gadget" dir="ltr" style=""><div id=":0.targetLanguage"><select class="goog-te-combo" aria-label="Language Translate Widget"><option value="">Select Language</option><option value="bn">Bengali</option><option value="en">English</option><option value="gu">Gujarati</option><option value="hi">Hindi</option><option value="kn">Kannada</option><option value="ml">Malayalam</option><option value="mr">Marathi</option><option value="or">Odia (Oriya)</option><option value="pa">Punjabi (Gurmukhi)</option><option value="ta">Tamil</option><option value="te">Telugu</option><option value="ur">Urdu</option></select></div>Powered by <span style="white-space:nowrap"><a class="VIpgJd-ZVi9od-l4eHX-hSRGPd" href="https://translate.google.com" target="_blank"><img src="https://www.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_42x16dp.png" width="37px" height="14px" style="padding-right: 3px" alt="Google Translate">Translate</a></span></div></div>
                         
                            </div>
                    
                 
                  
                        <div class="bigslam-top-bar-right bigslam-item-pdlr">
                            <div class="bigslam-top-bar-right-social">
                                <a href="https://www.facebook.com/myrbcl?mibextid=ZbWKwL" target="_blank" class="bigslam-top-bar-social-icon" title="facebook">
                                    <i class="fa fa-facebook"></i></a>
                                    <a href="https://www.youtube.com/@RBCL-RisingBharatCricketLeague" target="_blank" class="bigslam-top-bar-social-icon" title="youtube">
                                        <i class="fa fa-youtube"></i></a>
                                        <a href="https://instagram.com/rbcl.risingbharatcricketleague?igshid=YTQwZjQ0NmI0OA==" target="_blank" class="bigslam-top-bar-social-icon" title="instagram">
                                            <i class="fa fa-instagram"></i></a>
                                            <a href="https://api.whatsapp.com/send/?phone=919871940423&text&type=phone_number&app_absent=0" target="_blank" class="bigslam-top-bar-social-icon" title="whatsapp">
                                                <i class="fa fa-whatsapp"></i></a>
                                                <!--<a href="#" target="_blank" class="bigslam-top-bar-social-icon" title="vimeo">-->
                                                <!--    <i class="fa fa-vimeo"></i></a>-->
                                                </div>
                        </div>
                    </div>
                </div>
                <header class="bigslam-header-wrap bigslam-header-style-plain  bigslam-style-menu-right bigslam-sticky-navigation bigslam-style-slide">
                    <div class="bigslam-header-background"></div>
                    <div class="bigslam-header-container  bigslam-container">

                        <div class="bigslam-header-container-inner clearfix">
                            <div class="bigslam-logo  bigslam-item-pdlr">
                                <div class="bigslam-logo-inner">
                                    <a href="index.php"><img src="upload/RBCL-Logo1.png" style="height:90px; width:250px" alt="" width="200" height="191" title="logo"></a>
                                </div>
                            </div>
                            <div class="bigslam-navigation bigslam-item-pdlr clearfix ">
                                <div class="bigslam-main-menu" id="bigslam-main-menu">
                                    <ul id="menu-main-navigation-1" class="sf-menu">
                                        <li class="menu-item menu-item-home current-menu-item bigslam-normal-menu"><a href="index.php">HOME</a></li>
                                        <li class="menu-item menu-item-has-children bigslam-normal-menu"><a href="#" class="sf-with-ul-pre">ABOUT US</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item" data-size="60"><a href="what-is-rbcl.php">WHAT IS RBCL</a></li>
                                                <li class="menu-item" data-size="60"><a href="rbcl-gallery.php">RBCL GALLERY</a></li>
                                                <li class="menu-item" data-size="60"><a href="rbcl-organisers.php">RBCL ORGANISERS</a></li>
                                                <!--<li class="menu-item" data-size="60"><a href="">RBCL ADVISORY BOARD</a></li>-->
                                                <!--<li class="menu-item" data-size="60"><a href="">RBCL POLICIES</a></li>-->
                                            </ul>
                                        </li>

                                         <li class="menu-item menu-item-has-children bigslam-normal-menu"><a href="" class="sf-with-ul-pre">SELECTION</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item" data-size="60"><a href="rbcl-team.php">RBCL TEAMS</a></li>
                                                <li class="menu-item" data-size="60"><a href="process.php">RBCL SELECTION PROCESS</a></li>

                                                <li class="menu-item" data-size="60"><a href="rbcl-documents.php">RBCL DOCUMENTS</a></li>
                                               
                                            </ul>
                                        </li>

                                        <!--<li class="menu-item menu-item-has-children bigslam-normal-menu"><a href="" class="sf-with-ul-pre">COMMITTEES</a>-->
                                        <!--    <ul class="sub-menu">-->
                                        <!--        <li class="menu-item" data-size="60"><a href="">ANTI-CORRUPTION COMMITTEE</a></li>-->
                                        <!--        <li class="menu-item" data-size="60"><a href="">DISCIPLINARY COMMITTEE</a></li>-->
                                               
                                        <!--    </ul>-->
                                        <!--</li>-->

                                        

                                        <li class="menu-item  bigslam-normal-menu"><a href="rbcl-management.php
">MANAGEMENT</a></li>

                                        <li class="menu-item  bigslam-normal-menu"><a href="">TOUR MATCHES</a></li>
                                        <li class="menu-item  bigslam-normal-menu"><a href="contact.php">CONTACT US</a></li>

                                        <li class="menu-item  bigslam-normal-menu"><a href="pay-fees.php">PAY FEE</a></li>

                                        <li class="menu-item  bigslam-normal-menu"><a href="registration.php">REGISTRATION</a></li>
 
                                    </ul>
                                    <div class="bigslam-navigation-slide-bar bigslam-style-2" id="bigslam-navigation-slide-bar"></div>
                                </div>
                            
                            </div>
                            <!-- bigslam-navigation -->
                        </div>
                        <!-- bigslam-header-inner -->
                    </div>
                    <!-- bigslam-header-container -->

                </header>
                <!-- header -->
            </div>

            <div class="bigslam-page-title-wrap  bigslam-style-medium bigslam-left-align">
                <div class="bigslam-header-transparent-substitute"></div>
                <div class="bigslam-page-title-overlay"></div>
                <div class="bigslam-page-title-container bigslam-container">
                    <div class="bigslam-page-title-content bigslam-item-pdlr">
                        <h1 class="bigslam-page-title">CODE OF CONDUCT</h1>
                        <div class="bigslam-page-caption">CODE OF CONDUCT</div>
                    </div>
                </div>
            </div>


            <div class="bigslam-page-wrapper" id="bigslam-page-wrapper">
                <div class="gdlr-core-page-builder-body">
                    <div class="gdlr-core-pbf-wrapper ">
                        <div class="gdlr-core-pbf-background-wrap"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container-custom" style="max-width: 900px ;">
                                
                                
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align">
                                        <div class="gdlr-core-text-box-item-content">
                                            <h3>CODE OF CONDUCT</h3>
                                            <p style="font-size:18px; color:black !important;">RBCL CODE OF CONDUCT<br>
Match Officials shall not engage in any conduct which is prejudicial to the interests of the game of<br>
cricket, RBCL and/or the League including without limitation the following:<br>
2.1 Conduct that is contrary to the spirit of the game.<br>
2.2 Conduct that brings the game into disrepute.<br>
2.3 Match Officials shall not make or cause to be made any public pronouncement or media
comment (including via any social media platform) which is detrimental to:<br>
(a) the game of cricket in general; or<br>
(b) any particular Match between Teams in which any such Match Official is involved; or<br>
(c) the League; or<br>
(d) the RBCL; or<br>
(e) relations between RBCLand any Team .<br>
2.4 Match Officials shall not disclose or comment upon any alleged breach of this Code of Conduct
or the Code of Conduct for Players and Team Officials or any hearing, report or decision arising
from any such alleged breach unless such disclosure is required under the provisions of this
Code of Conduct or the Code of Conduct for Players and Team Officials.<br>
2.5 Match Officialsshall not engage, directly or indirectly, in betting or any conduct described in the
Appendix 1.<br>
2.6 Match Officials shall not use or in any way be concerned in the use or distribution of illegal
drugs.<br>
2.7 Match Officials shall at all times observe and comply with the provisions of any regulation of
RBCL which applies to Match Officials in the League including but not limited to the Operational
Rules.<br>
2.8 Using language or a gesture that is obscene, offensive or insulting to a Player, Team Official or
any other third person (including a spectator) during a Match.<br>
2.9 Abuse of any cricket equipment or clothing, ground equipment or fixtures and fittings during a
Match.<br>
The Preamble to the Laws of Cricket, sets out the definition of the Spirit of Cricket, as follows:
“Preamble – The Spirit of Cricket<br>
Cricket owes much of its appeal and enjoyment to the fact that it should be played not only according to
the Laws (which are incorporated within these Playing Conditions), but also within the Spirit of Cricket.
The major responsibility for ensuring fair play rests with the captains, but extends to all Players, Match
officials and, especially in junior cricket, teachers, coaches and parents.<br>
Respect is central to the Spirit of Cricket.<br>
Respect your captain, Team-mates, opponents and the authority of the Umpires.<br>
Play hard and play fair.<br>
Accept the Umpire’s decision.<br>
Create a positive atmosphere by your own conduct and encourage others to do likewise.<br>
Show self-discipline, even when things go against you.<br>
Congratulate the opposition on their successes and enjoy those of your own Team.<br>
Thank the officials and your opposition at the end of the match, whatever the result.<br>
Cricket is an exciting game that encourages leadership, friendship and Teamwork, which brings together
people from different nationalities, cultures and religions, especially when played within the Spirit of
Cricket.”</p> 
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                                  
                                
                               
                                 
                                 
                                 
                              
                                 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<footer>
                <div class="bigslam-footer-wrapper">
                    <div class="bigslam-footer-container bigslam-container clearfix">
                        <div class="bigslam-footer-column bigslam-item-pdlr bigslam-column-20">
                            <div id="text-11" class="widget widget_text bigslam-widget">
                                <h3 class="bigslam-widget-title">Contact Info</h3>
                                <div class="textwidget">
                                    <p>Welcome to the Rising Bharat Cricket League, managed by Shivay Sports Management Pvt Ltd, a registered entity with the Ministry of Company Affairs. Our league is not just a sporting event; it's a celebration of the game's spirit, uniting communities through thrilling cricket competitions. </p>
                                </div>
                            </div>
                        </div>
                        <div class="bigslam-footer-column bigslam-item-pdlr bigslam-column-20">
                            <div id="gdlr-core-custom-menu-widget-2" class="widget widget_gdlr-core-custom-menu-widget bigslam-widget">
                                <h3 class="bigslam-widget-title">Resources</h3>
                                <div class="menu-main-navigation-container">
                                    <ul id="menu-main-navigation-2" class="gdlr-core-custom-menu-widget gdlr-core-menu-style-half">
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-5136 current_page_item menu-item-5322"><a href="" aria-current="page">Home</a></li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-4641"><a href="rbcl-faqs.php">FAQ</a></li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-4654"><a href="what-is-rbcl.php">What is RBCL</a></li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-sp_team menu-item-4559"><a href="rbcl-team.php">Our Team</a></li>
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4688"><a href="rbcl-gallery.php">Our Gallery</a></li>
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4294"><a href="payment-policy.php">Payment Policy</a></li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-4782"><a href="process.php">Selection Process</a></li>
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4261"><a href="term-and-condition.php">Term & Condition</a></li>
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4294"><a href="rbcl-organisers.php">Organisers</a></li>
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4261"><a href="code-of-conduct.php">Code of Cunduct</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="bigslam-footer-column bigslam-item-pdlr bigslam-column-20">
                            <div id="text-10" class="widget widget_text bigslam-widget">
                                <h3 class="bigslam-widget-title">Newsletter</h3>
                                <div class="textwidget">
                                    <p>We&#8217;ll send updates straight to your inbox. Let&#8217;s stay connected! <span class="gdlr-core-space-shortcode" style="margin-top: -40px ;"></span></p>
                                </div>
                            </div>
                            <div id="gdlr-core-newsletter-widget-2" class="widget widget_gdlr-core-newsletter-widget bigslam-widget">
                                <div class="gdlr-core-with-fa-send-o-button tnp tnp-subscription gdlr-core-style-2">
                                    <form method="post" action="">

                                        <input type="hidden" name="nlang" value="">
                                        <div class="tnp-field tnp-field-email">
                                            <input class="tnp-email" type="email" name="ne" placeholder="Enter Your Email Address" required="">
                                        </div>
                                        <div class="tnp-field tnp-field-button" style="color: #fff;">
                                            <input class="tnp-submit" type="submit" value="Subscribe" style="background-color:#f27052;">
                                        </div>

                                    </form>
                                </div>
                            </div>
                            <div id="text-1" class="widget widget_text bigslam-widget">
                                <div class="textwidget"><span class="gdlr-core-space-shortcode" style="margin-top: -30px ;"></span>
                                    <!--<a href="#" target="_blank" rel="noopener noreferrer"><i class="fa fa-twitter" style="font-size: 20px ;color: #8a99c0 ;margin-right: 20px ;"></i></a>-->
                                    <a href="https://www.facebook.com/myrbcl?mibextid=ZbWKwL" target="_blank" rel="noopener noreferrer"><i class="fa fa-facebook" style="font-size: 20px ;color: #8a99c0 ;margin-right: 20px ;"></i></a>
                                    <a href="https://instagram.com/rbcl.risingbharatcricketleague?igshid=YTQwZjQ0NmI0OA==" target="_blank" rel="noopener noreferrer"><i class="fa fa-instagram" style="font-size: 20px ;color: #8a99c0 ;margin-right: 20px ;"></i></a>
                                    <a href="https://www.youtube.com/@RBCL-RisingBharatCricketLeague" target="_blank" rel="noopener noreferrer"><i class="fa fa-youtube" style="font-size: 20px ;color: #8a99c0 ;margin-right: 20px ;"></i></a>
                                    <a href="https://api.whatsapp.com/send/?phone=919871940423&text&type=phone_number&app_absent=0" target="_blank" rel="noopener noreferrer"><i class="fa fa-whatsapp" style="font-size: 20px ;color: #8a99c0 ;margin-right: 20px ;"></i></a>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bigslam-copyright-wrapper">
                    <div class="bigslam-copyright-container bigslam-container">
                        <div class="bigslam-copyright-text bigslam-item-pdlr">© Shivay Sports Management Pvt Ltd | All Rights Reserved | 2023</div>
                    </div>
                </div>
            </footer>
            
            <div class="whatsapp-link">
         <a href="https://api.whatsapp.com/send?phone=919871940423&amp;text=Hey%20there" target="_blank">
         <img src="img/whatspp-icon.gif">
         </a>
      </div>
      
      <style>
          .whatsapp-link img {
    height: 65px;
    width: 65px;
    position: fixed;
    left: 30px;
    bottom: 19px;
    z-index: 9999;
}
      </style>
      
        </div>
    </div><a href="#bigslam-top-anchor" class="bigslam-footer-back-to-top-button" id="bigslam-footer-back-to-top-button"><i class="fa fa-angle-up"></i></a>


    <script type='text/javascript' src='js/jquery/jquery.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='plugins/revslider/public/assets/js/revolution.tools.min.js'></script>
    <script type='text/javascript' src='plugins/revslider/public/assets/js/rs6.min.js'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var SnazzyDataForSnazzyMaps = [];
        SnazzyDataForSnazzyMaps = {
            "id": 38,
            "name": "Shades of Grey",
            "description": "A map with various shades of grey. Great for a website with a really dark theme. ",
            "url": "https:////snazzymaps.com//style//38//shades-of-grey",
            "imageUrl": "https:////snazzy-maps-cdn.azureedge.net//assets//38-shades-of-grey.png?v=20170407093939",
            "json": "[{/"featureType/":/"all/",/"elementType/":/"labels.text.fill/",/"stylers/":[{/"saturation/":36},{/"color/":/"#000000/"},{/"lightness/":40}]},{/"featureType/":/"all/",/"elementType/":/"labels.text.stroke/",/"stylers/":[{/"visibility/":/"on/"},{/"color/":/"#000000/"},{/"lightness/":16}]},{/"featureType/":/"all/",/"elementType/":/"labels.icon/",/"stylers/":[{/"visibility/":/"off/"}]},{/"featureType/":/"administrative/",/"elementType/":/"geometry.fill/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":20}]},{/"featureType/":/"administrative/",/"elementType/":/"geometry.stroke/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":17},{/"weight/":1.2}]},{/"featureType/":/"landscape/",/"elementType/":/"geometry/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":20}]},{/"featureType/":/"poi/",/"elementType/":/"geometry/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":21}]},{/"featureType/":/"road.highway/",/"elementType/":/"geometry.fill/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":17}]},{/"featureType/":/"road.highway/",/"elementType/":/"geometry.stroke/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":29},{/"weight/":0.2}]},{/"featureType/":/"road.arterial/",/"elementType/":/"geometry/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":18}]},{/"featureType/":/"road.local/",/"elementType/":/"geometry/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":16}]},{/"featureType/":/"transit/",/"elementType/":/"geometry/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":19}]},{/"featureType/":/"water/",/"elementType/":/"geometry/",/"stylers/":[{/"color/":/"#000000/"},{/"lightness/":17}]}]",
            "views": 264721,
            "favorites": 544,
            "createdBy": {
                "name": "Adam Krogh",
                "url": "https:////twitter.com//adamkrogh"
            },
            "createdOn": "2013-11-12T18:21:41.94",
            "tags": ["dark", "greyscale"],
            "colors": ["black", "gray"]
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='plugins/snazzy-maps/snazzymaps.js'></script>
    <script type="text/javascript">
        function setREVStartSize(t) {
            try {
                var h, e = document.getElementById(t.c).parentNode.offsetWidth;
                if (e = 0 === e || isNaN(e) ? window.innerWidth : e, t.tabw = void 0 === t.tabw ? 0 : parseInt(t.tabw), t.thumbw = void 0 === t.thumbw ? 0 : parseInt(t.thumbw), t.tabh = void 0 === t.tabh ? 0 : parseInt(t.tabh), t.thumbh = void 0 === t.thumbh ? 0 : parseInt(t.thumbh), t.tabhide = void 0 === t.tabhide ? 0 : parseInt(t.tabhide), t.thumbhide = void 0 === t.thumbhide ? 0 : parseInt(t.thumbhide), t.mh = void 0 === t.mh || "" == t.mh || "auto" === t.mh ? 0 : parseInt(t.mh, 0), "fullscreen" === t.layout || "fullscreen" === t.l) h = Math.max(t.mh, window.innerHeight);
                else {
                    for (var i in t.gw = Array.isArray(t.gw) ? t.gw : [t.gw], t.rl) void 0 !== t.gw[i] && 0 !== t.gw[i] || (t.gw[i] = t.gw[i - 1]);
                    for (var i in t.gh = void 0 === t.el || "" === t.el || Array.isArray(t.el) && 0 == t.el.length ? t.gh : t.el, t.gh = Array.isArray(t.gh) ? t.gh : [t.gh], t.rl) void 0 !== t.gh[i] && 0 !== t.gh[i] || (t.gh[i] = t.gh[i - 1]);
                    var r, a = new Array(t.rl.length),
                        n = 0;
                    for (var i in t.tabw = t.tabhide >= e ? 0 : t.tabw, t.thumbw = t.thumbhide >= e ? 0 : t.thumbw, t.tabh = t.tabhide >= e ? 0 : t.tabh, t.thumbh = t.thumbhide >= e ? 0 : t.thumbh, t.rl) a[i] = t.rl[i] < window.innerWidth ? 0 : t.rl[i];
                    for (var i in r = a[0], a) r > a[i] && 0 < a[i] && (r = a[i], n = i);
                    var d = e > t.gw[n] + t.tabw + t.thumbw ? 1 : (e - (t.tabw + t.thumbw)) / t.gw[n];
                    h = t.gh[n] * d + (t.tabh + t.thumbh)
                }
                void 0 === window.rs_init_css && (window.rs_init_css = document.head.appendChild(document.createElement("style"))), document.getElementById(t.c).height = h, window.rs_init_css.innerHTML += "#" + t.c + "_wrapper { height: " + h + "px }"
            } catch (t) {
                console.log("Failure at Presize of Slider:" + t)
            }
        };
    </script>


    <script type='text/javascript' src='plugins/goodlayers-core/plugins/script.js'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var gdlr_core_pbf = {
            "admin": "",
            "video": {
                "width": "640",
                "height": "360"
            },
            "ajax_url": "#",
            "ilightbox_skin": "dark"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='plugins/goodlayers-core/include/js/page-builder.js'></script>
    <script type='text/javascript' src='plugins/sportspress/assets/js/jquery.dataTables.min.js'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var localized_strings = {
            "days": "days",
            "hrs": "hrs",
            "mins": "mins",
            "secs": "secs",
            "previous": "Previous",
            "next": "Next"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='plugins/sportspress/assets/js/sportspress.js'></script>
    <script type='text/javascript' src='js/jquery/ui/effect.min.js'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var bigslam_script_core = {
            "home_url": "index.html"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='js/plugins.js'></script>
    <script type='text/javascript' src='plugins/google-map-plugin/assets/js/maps.js'></script>
    <script type="text/javascript">
        setREVStartSize({
            c: 'rev_slider_1_1',
            rl: [1240, 1240, 1240, 480],
            el: [900, 900, 900, 500],
            gw: [1240, 1240, 1240, 480],
            gh: [900, 900, 900, 500],
            layout: 'fullwidth',
            mh: "0"
        });
        var revapi1,
            tpj;
        jQuery(function() {
            tpj = jQuery;
            if (tpj("#rev_slider_1_1").revolution == undefined) {
                revslider_showDoubleJqueryError("#rev_slider_1_1");
            } else {
                revapi1 = tpj("#rev_slider_1_1").show().revolution({
                    jsFileLocation: "plugins/revslider/public/assets/js/",
                    sliderLayout: "fullwidth",
                    visibilityLevels: "1240,1240,1240,480",
                    gridwidth: "1240,1240,1240,480",
                    gridheight: "900,900,900,500",
                    minHeight: "",
                    editorheight: "900,768,960,500",
                    responsiveLevels: "1240,1240,1240,480",
                    disableProgressBar: "on",
                    navigation: {
                        mouseScrollNavigation: false,
                        onHoverStop: false,
                        arrows: {
                            enable: true,
                            style: "uranus",
                            hide_onleave: true,
                            left: {

                            },
                            right: {

                            }
                        }
                    },
                    fallbacks: {
                        allowHTML5AutoPlayOnAndroid: true
                    },
                });
            }

        });
    </script>
    <script>
        var htmlDivCss = unescape(".jost-font%7B%20font-family%3A%20Jost%20%21important%3B%20%7D");
        var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
        if (htmlDiv) {
            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
        } else {
            var htmlDiv = document.createElement('div');
            htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
            document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
        }
    </script>
    <script>
        var htmlDivCss = unescape("%23rev_slider_1_1_wrapper%20.uranus.tparrows%20%7B%0A%20%20width%3A50px%3B%0A%20%20height%3A50px%3B%0A%20%20background%3Argba%28255%2C255%2C255%2C0%29%3B%0A%20%7D%0A%20%23rev_slider_1_1_wrapper%20.uranus.tparrows%3Abefore%20%7B%0A%20width%3A50px%3B%0A%20height%3A50px%3B%0A%20line-height%3A50px%3B%0A%20font-size%3A40px%3B%0A%20transition%3Aall%200.3s%3B%0A-webkit-transition%3Aall%200.3s%3B%0A%20%7D%0A%20%0A%20%20%23rev_slider_1_1_wrapper%20.uranus.tparrows%3Ahover%3Abefore%20%7B%0A%20%20%20%20opacity%3A0.75%3B%0A%20%20%7D%0A");
        var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
        if (htmlDiv) {
            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
        } else {
            var htmlDiv = document.createElement('div');
            htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
            document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
        }
    </script>
    <script>
        var htmlDivCss = unescape("%0A%0A%0A");
        var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
        if (htmlDiv) {
            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
        } else {
            var htmlDiv = document.createElement('div');
            htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
            document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
        }
    </script>

    <script type="text/javascript">
        if (typeof revslider_showDoubleJqueryError === "undefined") {
            function revslider_showDoubleJqueryError(sliderID) {
                var err = "<div class='rs_error_message_box'>";
                err += "<div class='rs_error_message_oops'>Oops...</div>";
                err += "<div class='rs_error_message_content'>";
                err += "You have some jquery.js library include that comes after the Slider Revolution files js inclusion.<br>";
                err += "To fix this, you can:<br>&nbsp;&nbsp;&nbsp; 1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on";
                err += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jQuery.js inclusion and remove it";
                err += "</div>";
                err += "</div>";
                jQuery(sliderID).show().html(err);
            }
        }
    </script>
</body>

<!-- Mirrored from max-themes.net/demos/bigslam/soccer3/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 01 Dec 2023 13:27:02 GMT -->
</html>